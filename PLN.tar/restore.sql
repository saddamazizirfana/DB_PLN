--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_id_tarif_key;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_id_tagihan_key;
ALTER TABLE ONLY public.pengguna DROP CONSTRAINT pengguna_pkey;
ALTER TABLE ONLY public.pengguna DROP CONSTRAINT pengguna_id_pengguna_key;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_id_pembayaran_key;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_id_pelanggam_key;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_id_level_key;
ALTER TABLE ONLY public.admin DROP CONSTRAINT admin_pkey;
ALTER TABLE ONLY public.admin DROP CONSTRAINT admin_id_admin_key;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.pengguna;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP TABLE public.level;
DROP TABLE public.admin;
DROP TYPE public.status;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status AS ENUM (
    'Sudah Bayar',
    'Belum Bayar'
);


ALTER TYPE status OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE admin (
    id_admin character varying NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_admin character varying(50),
    id_level character varying(10)
);


ALTER TABLE admin OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying NOT NULL,
    nama_level character varying(50)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggam character varying NOT NULL,
    username character varying(50),
    password character varying(50),
    nomor_kwh integer,
    nama_pelanggan character varying(50),
    alamat text,
    id_tarif character varying(10)
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran character varying NOT NULL,
    id_tagihan character varying(10),
    id_pelanggan character varying(10),
    tanggal_pembayaran date,
    bulan_bayar character varying(20),
    biaya_admin integer,
    total_bayar integer,
    id_admin character varying(10)
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: pengguna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pengguna (
    id_pengguna character varying NOT NULL,
    id_pelanggan character varying(10),
    bulan character varying(12),
    tahun character varying(10),
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE pengguna OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan character varying NOT NULL,
    id_pengguna character varying(10),
    id_pelanggan character varying(10),
    bylan character varying(12),
    tahun character varying(6),
    jumlah_meter integer,
    status status
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif character varying NOT NULL,
    daya integer,
    tarifperkwh integer
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2856.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2857.dat';

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggam, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggam, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2852.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2854.dat';

--
-- Data for Name: pengguna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pengguna (id_pengguna, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY pengguna (id_pengguna, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2851.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_pengguna, id_pelanggan, bylan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_pengguna, id_pelanggan, bylan, tahun, jumlah_meter, status) FROM '$$PATH$$/2853.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2855.dat';

--
-- Name: admin admin_id_admin_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_id_admin_key UNIQUE (id_admin);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id_admin);


--
-- Name: level level_id_level_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_id_level_key UNIQUE (id_level);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: pelanggan pelanggan_id_pelanggam_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_id_pelanggam_key UNIQUE (id_pelanggam);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggam);


--
-- Name: pembayaran pembayaran_id_pembayaran_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_id_pembayaran_key UNIQUE (id_pembayaran);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: pengguna pengguna_id_pengguna_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pengguna
    ADD CONSTRAINT pengguna_id_pengguna_key UNIQUE (id_pengguna);


--
-- Name: pengguna pengguna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pengguna
    ADD CONSTRAINT pengguna_pkey PRIMARY KEY (id_pengguna);


--
-- Name: tagihan tagihan_id_tagihan_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_id_tagihan_key UNIQUE (id_tagihan);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_id_tarif_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_id_tarif_key UNIQUE (id_tarif);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- PostgreSQL database dump complete
--

